﻿
using CSV.Helper.Repository;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSVTest
{
    class Program
    {
        static void Main(string[] args)
        {
            CSVReader reader = new CSVReader();           
            using (FileStream stream = File.Open(@"c:\users\rkharat\documents\visual studio 2015\Projects\CSVSln\CSVTest\Testing.csv", FileMode.Open))
            {
                List<Employee> emp =  reader.Read<Employee>(stream, Encoding.UTF8);
            }

        }

        
    }
    public class Employee
    {
        public DateTime DOB { get; set; }
        public string Name { get; set; }
        public int ID { get; set; }      
        public string Address { get; set; }
        
    }
}
