﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSVReadWrite.Interface
{
    public interface ICSVReader
    {
        /// <summary>
        /// This is use to read CSV file
        /// </summary>
        /// <typeparam name="T">Read CSV file with specified file</typeparam>
        /// <param name="filepath">CSV file path</param>
        /// <param name="seperator">delimeter</param>
        /// <returns>return List of type</returns>
        List<T> Read<T>(string filepath, char seperator = ',');

        /// <summary>
        /// This is use to read CSV file
        /// </summary>
        /// <typeparam name="T">Read CSV file with specified file</typeparam>
        /// <param name="filepath">Stream of file/param>
        /// <param name="seperator">delimeter</param>
        /// <returns>return List of type</returns>
        List<T> Read<T>(Stream fileStream, Encoding encoding, char seperator = ',');
    }
}
