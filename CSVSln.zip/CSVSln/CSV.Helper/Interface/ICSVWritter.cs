﻿using System;

using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSVReadWrite.Interface
{
    public interface ICSVWritter
    {
        /// <summary>
        /// Write list to CSV file
        /// </summary>
        /// <typeparam name="T">Type of object pass to write in csv</typeparam>
        /// <param name="list">List of object</param>
        /// <param name="filePath">File location to write CSV</param>
        /// <param name="seperator">Delimeter</param>
        /// <returns>if writting file is succesfull the you will revice true and else it will false</returns>
        bool Write<T>(List<T> list, string filePath, string seperator = ",");
    }
}
