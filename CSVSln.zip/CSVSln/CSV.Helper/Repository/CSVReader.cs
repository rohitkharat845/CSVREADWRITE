﻿using CSVReadWrite.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.CompilerServices;
using System.Reflection;
using System.ComponentModel;

namespace CSVReadWrite.Repository
{
    public class CSVReader : ICSVReader
    {
        public List<T> Read<T>(Stream fileStream, Encoding encoding,char seperator = ',')
        {
            if (fileStream ==null)
                throw new Exception("File path is null or empty");

            Type type = typeof(T);
            List<T> searchList = new List<T>();
            List<PropertyInfo> propertiesNames = type.GetProperties().ToList();
            List<string> Headings = new List<string>();
            using (var reader = new StreamReader(fileStream,encoding))
            {
                int count = 0;
                while (!reader.EndOfStream)
                {
                    List<string> Values = new List<string>();
                    if (count == 0)
                    {
                        Headings = reader.ReadLine().Split(seperator).ToList();
                    }
                    else
                        Values = reader.ReadLine().Split(seperator).ToList();

                    T obj = (T)Activator.CreateInstance(type);
                    if (Values.Count == propertiesNames.Count && count > 0)
                    {
                        if (count > 0)
                        {
                            int index = 0;

                            foreach (var item in propertiesNames)
                            {

                                var converter = TypeDescriptor.GetConverter(item.PropertyType);
                                var convertedObject = converter.ConvertFromString(Values[Headings.FindIndex(x => x == item.Name)]);
                                obj.GetType().GetProperty(item.Name).SetValue(obj, convertedObject);
                                index++;
                            }
                            searchList.Add(obj);
                        }
                    }
                    count++;
                }
            }
            return searchList;
        }

        public List<T> Read<T>(string filepath, char seperator = ',')
        {
            if (string.IsNullOrWhiteSpace(filepath))
                throw new Exception("File path is null or empty");

            Type type = typeof(T);
            List<T> searchList = new List<T>();
            List<PropertyInfo> propertiesNames = type.GetProperties().ToList();
            List<string> Headings = new List<string>();
            using (var reader = new StreamReader(File.OpenRead(filepath)))
            {

                int count = 0;
                while (!reader.EndOfStream)
                {

                    List<string> Values = new List<string>();
                    if (count == 0)
                    {
                        Headings = reader.ReadLine().Split(seperator).ToList();
                    }
                    else
                        Values = reader.ReadLine().Split(seperator).ToList();


                    T obj = (T)Activator.CreateInstance(type);
                    if (Values.Count == propertiesNames.Count && count > 0)
                    {
                        if (count > 0)
                        {
                            int index = 0;

                            foreach (var item in propertiesNames)
                            {

                                var converter = TypeDescriptor.GetConverter(item.PropertyType);
                                var convertedObject = converter.ConvertFromString(Values[Headings.FindIndex(x => x == item.Name)]);
                                obj.GetType().GetProperty(item.Name).SetValue(obj, convertedObject);
                                index++;
                            }
                            searchList.Add(obj);
                        }

                    }
                    count++;

                }
            }
            return searchList;
        }



        //public void Read(File file, string seperator = ",")
        //{

        //}
    }
}
