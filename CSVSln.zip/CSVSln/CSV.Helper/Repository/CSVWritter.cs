﻿using CSVReadWrite.Interface;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace CSVReadWrite.Repository
{
    internal class CSVWritter : ICSVWritter
    {

        /// <summary>
        /// Write list to CSV file
        /// </summary>
        /// <typeparam name="T">Type of object pass to write in csv</typeparam>
        /// <param name="list">List of object</param>
        /// <param name="filePath">File location to write CSV</param>
        /// <param name="seperator">Delimeter</param>
        /// <returns>if writting file is succesfull the you will revice true and else it will false</returns>
        public bool Write<T>(List<T> list, string filePath, string seperator = ",")
        {
            if (list == null || list.Count == 0)
                throw new Exception("List object is empty");
            if (string.IsNullOrWhiteSpace(filePath))
                throw new Exception("file path is empty");

            Type type = typeof(T);
            List<string> propertiesNames = type.GetProperties().Select(x => x.Name).ToList();
            string str = string.Join(seperator, propertiesNames);
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(str + seperator);
            foreach (var item in list)
            {
                foreach (var property in propertiesNames)
                {
                    string value = item.GetType().GetProperty(property).GetValue(item).ToString();
                    sb.Append(value + seperator);
                }
                sb.AppendLine();
            }
            File.WriteAllText(filePath, sb.ToString());
            return true;
        }
    }
}
